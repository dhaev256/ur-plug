import 'package:cloud_firestore/cloud_firestore.dart';
import '../models/provider_profile.dart';
import '../models/review.dart';
import '../models/chat_and_jobs.dart';
import '../models/zone.dart';

/// All Firestore reads and writes for Ur Plug.
///
/// Collection layout:
///   /users/{uid}              — consumer profiles
///   /providers/{id}           — provider profiles + sub-collections
///   /providers/{id}/reviews   — consumer reviews for that provider
///   /chats/{chatId}           — chat metadata (consumerId, providerId)
///   /chats/{chatId}/messages  — individual messages
///   /jobPosts/{id}            — consumer job requests (public board)
///
/// All writes go through this service so screens stay thin.
class FirestoreService {
  FirestoreService._();
  static final FirestoreService instance = FirestoreService._();

  final FirebaseFirestore _db = FirebaseFirestore.instance;

  // ── Providers ──────────────────────────────────────────────────────

  /// Fetch all providers. In production, add .where() filters for
  /// category and paginate with startAfterDocument.
  Future<List<ProviderProfile>> fetchProviders({String? categoryId}) async {
    Query<Map<String, dynamic>> q = _db.collection('providers');
    if (categoryId != null && categoryId.isNotEmpty) {
      q = q.where('categoryId', isEqualTo: categoryId);
    }
    final snap = await q.get();
    return snap.docs.map((d) => _providerFromDoc(d)).toList();
  }

  /// Fetch a single provider by ID.
  Future<ProviderProfile?> fetchProvider(String id) async {
    final doc = await _db.collection('providers').doc(id).get();
    if (!doc.exists) return null;
    return _providerFromDoc(doc);
  }

  /// Register a new provider document.
  Future<void> createProvider(ProviderProfile profile) async {
    await _db.collection('providers').doc(profile.id).set(_providerToMap(profile));
  }

  /// Update provider's open-for-work status.
  Future<void> setOpenForWork(String providerId, bool isOpen) async {
    await _db.collection('providers').doc(providerId).update({'isOpenForWork': isOpen});
  }

  // ── Reviews ────────────────────────────────────────────────────────

  /// Fetch all reviews for a provider, newest first.
  Stream<List<Review>> reviewsStream(String providerId) {
    return _db
        .collection('providers')
        .doc(providerId)
        .collection('reviews')
        .orderBy('createdAt', descending: true)
        .snapshots()
        .map((snap) => snap.docs.map((d) => _reviewFromDoc(d)).toList());
  }

  /// Post a new consumer review.
  Future<void> addReview(String providerId, Review review) async {
    await _db
        .collection('providers')
        .doc(providerId)
        .collection('reviews')
        .doc(review.id)
        .set(_reviewToMap(review));
  }

  /// Provider posts one public response to a review.
  Future<void> respondToReview(
      String providerId, String reviewId, String response) async {
    await _db
        .collection('providers')
        .doc(providerId)
        .collection('reviews')
        .doc(reviewId)
        .update({'providerResponse': response});
  }

  // ── Chat ───────────────────────────────────────────────────────────

  /// Real-time stream of messages in a chat thread.
  Stream<List<ChatMessage>> messagesStream(String chatId) {
    return _db
        .collection('chats')
        .doc(chatId)
        .collection('messages')
        .orderBy('sentAt')
        .snapshots()
        .map((snap) => snap.docs.map((d) => _messageFromDoc(d)).toList());
  }

  /// Send a text message.
  Future<void> sendMessage(String chatId, ChatMessage message) async {
    await _db
        .collection('chats')
        .doc(chatId)
        .collection('messages')
        .doc(message.id)
        .set(_messageToMap(message));
  }

  // ── Job Posts ──────────────────────────────────────────────────────

  /// Public job request board — all open posts, newest first.
  Stream<List<JobPost>> jobPostsStream() {
    return _db
        .collection('jobPosts')
        .where('isOpen', isEqualTo: true)
        .orderBy('createdAt', descending: true)
        .snapshots()
        .map((snap) => snap.docs.map((d) => _jobFromDoc(d)).toList());
  }

  /// Post a new job request.
  Future<void> postJob(JobPost job) async {
    await _db.collection('jobPosts').doc(job.id).set(_jobToMap(job));
  }

  // ── Serialisation helpers ──────────────────────────────────────────

  ProviderProfile _providerFromDoc(DocumentSnapshot<Map<String, dynamic>> doc) {
    final d = doc.data()!;
    return ProviderProfile(
      id: doc.id,
      name: d['name'] as String,
      categoryId: d['categoryId'] as String,
      tier: d['tier'] == 'gold' ? ProviderTier.gold : ProviderTier.standard,
      businessDescription: d['businessDescription'] as String,
      zone: ZoneAddress(
        regionId: d['regionId'] as String,
        districtId: d['districtId'] as String,
        divisionId: d['divisionId'] as String,
        parishId: d['parishId'] as String,
        landmark: d['landmark'] as String?,
      ),
      ratingAverage: (d['ratingAverage'] as num?)?.toDouble() ?? 0,
      ratingCount: (d['ratingCount'] as int?) ?? 0,
      completedJobs: (d['completedJobs'] as int?) ?? 0,
      responsivenessScore: (d['responsivenessScore'] as num?)?.toDouble() ?? 0.5,
      isOpenForWork: (d['isOpenForWork'] as bool?) ?? true,
      isFeatured: (d['isFeatured'] as bool?) ?? false,
      identityVerified: (d['identityVerified'] as bool?) ?? false,
      coverImageUrl: d['coverImageUrl'] as String?,
      avatarUrl: d['avatarUrl'] as String?,
    );
  }

  Map<String, dynamic> _providerToMap(ProviderProfile p) => {
        'name': p.name,
        'categoryId': p.categoryId,
        'tier': p.tier.name,
        'businessDescription': p.businessDescription,
        'regionId': p.zone.regionId,
        'districtId': p.zone.districtId,
        'divisionId': p.zone.divisionId,
        'parishId': p.zone.parishId,
        'landmark': p.zone.landmark,
        'ratingAverage': p.ratingAverage,
        'ratingCount': p.ratingCount,
        'completedJobs': p.completedJobs,
        'responsivenessScore': p.responsivenessScore,
        'isOpenForWork': p.isOpenForWork,
        'isFeatured': p.isFeatured,
        'identityVerified': p.identityVerified,
        'coverImageUrl': p.coverImageUrl,
        'avatarUrl': p.avatarUrl,
      };

  Review _reviewFromDoc(DocumentSnapshot<Map<String, dynamic>> doc) {
    final d = doc.data()!;
    return Review(
      id: doc.id,
      providerId: d['providerId'] as String,
      consumerDisplayName: d['consumerDisplayName'] as String,
      stars: d['stars'] as int,
      comment: d['comment'] as String,
      createdAt: (d['createdAt'] as Timestamp).toDate(),
      providerResponse: d['providerResponse'] as String?,
    );
  }

  Map<String, dynamic> _reviewToMap(Review r) => {
        'providerId': r.providerId,
        'consumerDisplayName': r.consumerDisplayName,
        'stars': r.stars,
        'comment': r.comment,
        'createdAt': Timestamp.fromDate(r.createdAt),
        'providerResponse': r.providerResponse,
      };

  ChatMessage _messageFromDoc(DocumentSnapshot<Map<String, dynamic>> doc) {
    final d = doc.data()!;
    return ChatMessage(
      id: doc.id,
      senderId: d['senderId'] as String,
      type: MessageType.values.byName(d['type'] as String),
      text: d['text'] as String?,
      sentAt: (d['sentAt'] as Timestamp).toDate(),
    );
  }

  Map<String, dynamic> _messageToMap(ChatMessage m) => {
        'senderId': m.senderId,
        'type': m.type.name,
        'text': m.text,
        'sentAt': Timestamp.fromDate(m.sentAt),
      };

  JobPost _jobFromDoc(DocumentSnapshot<Map<String, dynamic>> doc) {
    final d = doc.data()!;
    return JobPost(
      id: doc.id,
      consumerId: d['consumerId'] as String,
      categoryId: d['categoryId'] as String,
      description: d['description'] as String,
      zone: ZoneAddress(
        regionId: d['regionId'] as String,
        districtId: d['districtId'] as String,
        divisionId: d['divisionId'] as String,
        parishId: d['parishId'] as String,
      ),
      createdAt: (d['createdAt'] as Timestamp).toDate(),
      isOpen: (d['isOpen'] as bool?) ?? true,
    );
  }

  Map<String, dynamic> _jobToMap(JobPost j) => {
        'consumerId': j.consumerId,
        'categoryId': j.categoryId,
        'description': j.description,
        'regionId': j.zone.regionId,
        'districtId': j.zone.districtId,
        'divisionId': j.zone.divisionId,
        'parishId': j.zone.parishId,
        'createdAt': Timestamp.fromDate(j.createdAt),
        'isOpen': j.isOpen,
      };
}
