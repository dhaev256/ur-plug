import 'package:flutter/foundation.dart';
import 'package:firebase_auth/firebase_auth.dart';

/// Phone-OTP authentication service.
///
/// ═══════════════════════════════════════════════════════════════════════════
/// WEB / FlutLab DEMO MODE
/// ═══════════════════════════════════════════════════════════════════════════
/// FlutLab runs Flutter Web. The Firebase Web SDK triggers reCAPTCHA Enterprise
/// automatically whenever firebase_auth is used in a browser — this fails in
/// any environment without a verified Firebase project domain.
///
/// When [kIsWeb] == true this service is FULLY LOCAL:
///   • No Firebase SDK methods are called at all.
///   • sendOtp()   → always succeeds after a short simulated delay.
///   • verifyOtp() → accepts demo code "123456" for any number.
///   • currentUser → returns a fake UserInfo object.
///
/// On real Android / iOS builds, full Firebase phone auth runs normally.
/// ═══════════════════════════════════════════════════════════════════════════
class FirebaseAuthService {
  FirebaseAuthService._();
  static final FirebaseAuthService instance = FirebaseAuthService._();

  // ── Web demo state ────────────────────────────────────────────────────────
  static const _demoOtpCode = '123456';
  bool _demoSignedIn = false;

  // ── Native Firebase ───────────────────────────────────────────────────────
  FirebaseAuth? get _auth => kIsWeb ? null : FirebaseAuth.instance;

  bool get isSignedIn => kIsWeb ? _demoSignedIn : (_auth?.currentUser != null);

  Stream<bool> get authStateStream {
    if (kIsWeb) {
      return Stream.value(_demoSignedIn);
    }
    return _auth!.authStateChanges().map((u) => u != null);
  }

  /// Step 1 — initiate OTP flow.
  /// On web: simulates success immediately.
  /// On native: calls Firebase verifyPhoneNumber.
  Future<void> sendOtp({
    required String phoneNumber,
    required void Function(String verificationId) onCodeSent,
    required void Function(String errorMessage) onError,
  }) async {
    if (kIsWeb) {
      // ── WEB DEMO ─────────────────────────────────────────────────────────
      await Future.delayed(const Duration(milliseconds: 900));
      onCodeSent('demo-web-token'); // not a real token
      return;
    }

    // ── NATIVE ───────────────────────────────────────────────────────────────
    try {
      await _auth!.verifyPhoneNumber(
        phoneNumber: phoneNumber,
        timeout: const Duration(seconds: 60),
        verificationCompleted: (PhoneAuthCredential credential) async {
          // Android auto-retrieval
          await _auth!.signInWithCredential(credential);
        },
        verificationFailed: (FirebaseAuthException e) {
          onError(_friendlyFirebaseError(e));
        },
        codeSent: (String verificationId, int? resendToken) {
          onCodeSent(verificationId);
        },
        codeAutoRetrievalTimeout: (_) {},
      );
    } catch (e) {
      onError('Could not send OTP. Check your number and try again.');
    }
  }

  /// Step 2 — verify the code the user entered.
  /// On web: accepts "123456", rejects anything else.
  /// On native: submits to Firebase.
  Future<bool> verifyOtp({
    required String verificationId,
    required String smsCode,
  }) async {
    if (kIsWeb) {
      // ── WEB DEMO ─────────────────────────────────────────────────────────
      await Future.delayed(const Duration(milliseconds: 700));
      if (smsCode.trim() == _demoOtpCode) {
        _demoSignedIn = true;
        return true;
      }
      return false;
    }

    // ── NATIVE ───────────────────────────────────────────────────────────────
    try {
      final credential = PhoneAuthProvider.credential(
        verificationId: verificationId,
        smsCode: smsCode,
      );
      final result = await _auth!.signInWithCredential(credential);
      return result.user != null;
    } on FirebaseAuthException catch (e) {
      debugPrint('verifyOtp error: ${e.code}');
      return false;
    }
  }

  Future<void> signOut() async {
    if (kIsWeb) {
      _demoSignedIn = false;
      return;
    }
    await _auth!.signOut();
  }

  String _friendlyFirebaseError(FirebaseAuthException e) {
    switch (e.code) {
      case 'invalid-phone-number':
        return 'Invalid phone number. Use format: +256 7XX XXX XXX';
      case 'too-many-requests':
        return 'Too many attempts. Please wait a few minutes.';
      case 'quota-exceeded':
        return 'SMS quota exceeded. Try again later.';
      case 'network-request-failed':
        return 'No internet connection. Check your network.';
      default:
        return e.message ?? 'Authentication failed. Please try again.';
    }
  }
}
