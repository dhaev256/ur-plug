import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'app.dart';
import 'firebase_options.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // ── Firebase initialisation ───────────────────────────────────────────────
  // FlutLab runs Flutter Web in a browser. The Firebase Web SDK automatically
  // tries to configure reCAPTCHA Enterprise on startup — this fails in a
  // sandbox with placeholder credentials and floods the console with errors.
  //
  // Fix: skip Firebase.initializeApp() entirely on web. The app runs in full
  // demo mode on web (any phone + OTP code "123456").
  // On native Android / iOS, Firebase initialises normally.
  // ─────────────────────────────────────────────────────────────────────────
  if (!kIsWeb) {
    try {
      await Firebase.initializeApp(
        options: DefaultFirebaseOptions.currentPlatform,
      );
    } catch (e) {
      // Misconfigured credentials on first run — app still launches.
      debugPrint('Firebase init skipped: $e');
    }
  }

  runApp(const UrPlugApp());
}
