// firebase_options.dart
//
// These are PLACEHOLDER values for FlutLab preview.
// The app runs in demo mode — no real Firebase calls are made in the browser.
//
// TO GO LIVE (native Android/iOS build):
//   1. Create a Firebase project at https://console.firebase.google.com
//   2. Add your Android app (package: com.urplug.app)
//   3. Add your iOS app (bundle ID: com.urplug.app)
//   4. Run: dart pub global activate flutterfire_cli
//            flutterfire configure
//   This file will be auto-replaced with your real values.

import 'package:firebase_core/firebase_core.dart' show FirebaseOptions;
import 'package:flutter/foundation.dart'
    show defaultTargetPlatform, kIsWeb, TargetPlatform;

class DefaultFirebaseOptions {
  static FirebaseOptions get currentPlatform {
    if (kIsWeb) return web;
    switch (defaultTargetPlatform) {
      case TargetPlatform.android:
        return android;
      case TargetPlatform.iOS:
        return ios;
      default:
        return web;
    }
  }

  static const FirebaseOptions web = FirebaseOptions(
    apiKey: 'AIzaSy-PLACEHOLDER-WEB-KEY',
    appId: '1:000000000000:web:0000000000000000000000',
    messagingSenderId: '000000000000',
    projectId: 'urplug-app',
    storageBucket: 'urplug-app.appspot.com',
    authDomain: 'urplug-app.firebaseapp.com',
  );

  static const FirebaseOptions android = FirebaseOptions(
    apiKey: 'AIzaSy-PLACEHOLDER-ANDROID-KEY',
    appId: '1:000000000000:android:0000000000000000',
    messagingSenderId: '000000000000',
    projectId: 'urplug-app',
    storageBucket: 'urplug-app.appspot.com',
  );

  static const FirebaseOptions ios = FirebaseOptions(
    apiKey: 'AIzaSy-PLACEHOLDER-IOS-KEY',
    appId: '1:000000000000:ios:0000000000000000',
    messagingSenderId: '000000000000',
    projectId: 'urplug-app',
    storageBucket: 'urplug-app.appspot.com',
    iosBundleId: 'com.urplug.app',
  );
}
