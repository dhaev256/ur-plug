import 'package:flutter/material.dart';
import 'package:provider/provider.dart' as pv;
import '../../models/service_category.dart';
import '../../state/app_state.dart';

class ProviderRegistrationScreen extends StatefulWidget {
  const ProviderRegistrationScreen({super.key});

  @override
  State<ProviderRegistrationScreen> createState() => _ProviderRegistrationScreenState();
}

class _ProviderRegistrationScreenState extends State<ProviderRegistrationScreen> {
  final _formKey = GlobalKey<FormState>();
  final Set<String> _selectedCategories = {};
  final _descController = TextEditingController();
  final _nationalIdController = TextEditingController();
  final _landmarkController = TextEditingController();
  final _contactController = TextEditingController();
  bool _submitting = false;
  bool _wantsGoldTier = false;

  Future<void> _submit() async {
    if (!_formKey.currentState!.validate()) return;
    if (_selectedCategories.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Select at least one service category (or "Others").')),
      );
      return;
    }
    setState(() => _submitting = true);
    // TODO: submit to Firestore — store National ID securely (not plaintext),
    // create provider row as Standard tier by default; if _wantsGoldTier,
    // also create a verification-queue entry for admin document review.
    await Future.delayed(const Duration(milliseconds: 700));
    if (!mounted) return;
    setState(() => _submitting = false);
    pv.Provider.of<AppState>(context, listen: false).completeProviderRegistration('p1');
    Navigator.of(context).pop();
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(_wantsGoldTier
            ? 'Registered! Your Gold Tier documents are pending admin review.'
            : 'You\'re registered as a Standard Tier provider.'),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Register as a Provider')),
      body: Form(
        key: _formKey,
        child: ListView(
          padding: const EdgeInsets.all(18),
          children: [
            const Text('Service categories', style: TextStyle(fontWeight: FontWeight.w700)),
            const SizedBox(height: 4),
            Text(
              'Tick every category your business covers. If it isn\'t listed, tick "Others".',
              style: TextStyle(fontSize: 12.5, color: Theme.of(context).colorScheme.onSurface.withOpacity(0.6)),
            ),
            const SizedBox(height: 10),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: DefaultCategories.all.map((c) {
                final selected = _selectedCategories.contains(c.id);
                return FilterChip(
                  avatar: Icon(c.icon, size: 16),
                  label: Text(c.label),
                  selected: selected,
                  onSelected: (v) => setState(() {
                    v ? _selectedCategories.add(c.id) : _selectedCategories.remove(c.id);
                  }),
                );
              }).toList(),
            ),
            const SizedBox(height: 20),
            TextFormField(
              controller: _descController,
              maxLines: 4,
              decoration: const InputDecoration(labelText: 'Business description'),
              validator: (v) => (v == null || v.trim().isEmpty) ? 'Required' : null,
            ),
            const SizedBox(height: 14),
            TextFormField(
              controller: _nationalIdController,
              decoration: const InputDecoration(labelText: 'National ID number'),
              validator: (v) => (v == null || v.trim().isEmpty) ? 'Required for all providers' : null,
            ),
            const SizedBox(height: 14),
            TextFormField(
              controller: _landmarkController,
              decoration: const InputDecoration(
                labelText: 'Local landmark (e.g. "Opposite Shell Ntinda")',
              ),
              validator: (v) => (v == null || v.trim().isEmpty) ? 'Required' : null,
            ),
            const SizedBox(height: 14),
            TextFormField(
              controller: _contactController,
              keyboardType: TextInputType.phone,
              decoration: const InputDecoration(labelText: 'Contact phone number'),
              validator: (v) => (v == null || v.trim().isEmpty) ? 'Required' : null,
            ),
            const SizedBox(height: 8),
            Text(
              'Operating zones: your Region / District / Division / Parish are '
              'pulled from your account zone and can be edited any time in Provider settings.',
              style: TextStyle(fontSize: 12, color: Theme.of(context).colorScheme.onSurface.withOpacity(0.55)),
            ),
            const SizedBox(height: 18),
            SwitchListTile(
              contentPadding: EdgeInsets.zero,
              title: const Text('Apply for Gold Tier', style: TextStyle(fontWeight: FontWeight.w700)),
              subtitle: const Text(
                'Requires URA TIN, URSB certificate, trading licence, or professional guild membership for admin review.',
                style: TextStyle(fontSize: 12),
              ),
              value: _wantsGoldTier,
              onChanged: (v) => setState(() => _wantsGoldTier = v),
            ),
            const SizedBox(height: 20),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: _submitting ? null : _submit,
                child: _submitting
                    ? const SizedBox(
                        height: 20, width: 20,
                        child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
                    : const Text('Submit Registration'),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
