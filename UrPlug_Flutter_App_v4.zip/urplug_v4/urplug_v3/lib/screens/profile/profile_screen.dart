import 'package:flutter/material.dart';
import 'package:provider/provider.dart' as pv;
import '../../models/chat_and_jobs.dart';
import '../../state/app_state.dart';
import '../../theme/app_colors.dart';
import '../admin/admin_login_screen.dart';
import '../provider/provider_dashboard_screen.dart';
import 'provider_registration_screen.dart';

class ProfileScreen extends StatelessWidget {
  const ProfileScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final app = pv.Provider.of<AppState>(context);
    final user = app.currentUser;

    if (app.mode == AppMode.provider && user.isRegisteredProvider) {
      return const ProviderDashboardScreen();
    }

    return Scaffold(
      appBar: AppBar(title: const Text('Profile')),
      body: ListView(
        padding: const EdgeInsets.all(18),
        children: [

          // ── User card ───────────────────────────────────────────────
          Row(
            children: [
              CircleAvatar(
                radius: 30,
                backgroundColor: AppColors.primaryGreenLight,
                child: Text(
                  user.displayName.isNotEmpty ? user.displayName[0] : '?',
                  style: const TextStyle(
                      color: AppColors.primaryGreen,
                      fontSize: 22,
                      fontWeight: FontWeight.w800),
                ),
              ),
              const SizedBox(width: 14),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(user.displayName,
                      style: const TextStyle(
                          fontSize: 18, fontWeight: FontWeight.w800)),
                  const SizedBox(height: 2),
                  Text(user.maskedPhone,
                      style: TextStyle(
                          color: Theme.of(context)
                              .colorScheme
                              .onSurface
                              .withOpacity(0.6))),
                ],
              ),
            ],
          ),
          const SizedBox(height: 24),

          // ── Provider mode switch ─────────────────────────────────────
          if (user.isRegisteredProvider)
            Container(
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                color: AppColors.primaryGreenLight,
                borderRadius: BorderRadius.circular(14),
              ),
              child: Row(
                children: [
                  const Icon(Icons.storefront_outlined,
                      color: AppColors.primaryGreen),
                  const SizedBox(width: 10),
                  const Expanded(
                    child: Text('Switch to Provider Mode',
                        style: TextStyle(fontWeight: FontWeight.w700)),
                  ),
                  Switch(
                    value: app.mode == AppMode.provider,
                    activeTrackColor: AppColors.primaryGreen,
                    onChanged: (_) => app.toggleMode(),
                  ),
                ],
              ),
            )
          else
            SizedBox(
              width: double.infinity,
              child: OutlinedButton.icon(
                onPressed: () => Navigator.of(context, rootNavigator: true).push(MaterialPageRoute(
                    builder: (_) => const ProviderRegistrationScreen())),
                icon: const Icon(Icons.add_business_outlined),
                label: const Text('Register as a Service Provider'),
              ),
            ),

          const SizedBox(height: 20),
          const Divider(),
          _ProfileTile(
              icon: Icons.bookmark_border,
              label: 'My Saved Providers',
              onTap: () {}),
          _ProfileTile(
              icon: Icons.star_border, label: 'My Reviews', onTap: () {}),
          const Divider(),
          _ProfileTile(
              icon: Icons.dark_mode_outlined,
              label: 'Theme',
              onTap: () => _showThemeSheet(context, app)),
          _ProfileTile(
              icon: Icons.person_add_alt_outlined,
              label: 'Invite a Friend',
              onTap: () {}),
          _ProfileTile(
              icon: Icons.info_outline, label: 'About Ur Plug', onTap: () {}),

          const Divider(),

          // ── Admin access ─────────────────────────────────────────────
          _ProfileTile(
            icon: Icons.admin_panel_settings_outlined,
            label: 'Admin Access',
            iconColor: AppColors.deepBlue,
            textColor: AppColors.deepBlue,
            onTap: () => Navigator.of(context, rootNavigator: true).push(
              MaterialPageRoute(builder: (_) => const AdminLoginScreen()),
            ),
          ),

          const Divider(),

          _ProfileTile(
              icon: Icons.logout,
              label: 'Sign Out',
              onTap: () {},
              isDestructive: true),
        ],
      ),
    );
  }

  void _showThemeSheet(BuildContext context, AppState app) {
    showModalBottomSheet(
      context: context,
      builder: (_) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            RadioListTile<ThemeMode>(
              title: const Text('System default'),
              value: ThemeMode.system,
              groupValue: app.themeMode,
              onChanged: (v) {
                app.setThemeMode(v!);
                Navigator.pop(context);
              },
            ),
            RadioListTile<ThemeMode>(
              title: const Text('Light'),
              value: ThemeMode.light,
              groupValue: app.themeMode,
              onChanged: (v) {
                app.setThemeMode(v!);
                Navigator.pop(context);
              },
            ),
            RadioListTile<ThemeMode>(
              title: const Text('Dark'),
              value: ThemeMode.dark,
              groupValue: app.themeMode,
              onChanged: (v) {
                app.setThemeMode(v!);
                Navigator.pop(context);
              },
            ),
          ],
        ),
      ),
    );
  }
}

class _ProfileTile extends StatelessWidget {
  final IconData icon;
  final String label;
  final VoidCallback onTap;
  final bool isDestructive;
  final Color? iconColor;
  final Color? textColor;

  const _ProfileTile({
    required this.icon,
    required this.label,
    required this.onTap,
    this.isDestructive = false,
    this.iconColor,
    this.textColor,
  });

  @override
  Widget build(BuildContext context) {
    final defaultColor = Theme.of(context).colorScheme.onSurface;
    final resolvedColor = isDestructive
        ? AppColors.danger
        : (iconColor ?? defaultColor);
    final resolvedTextColor = isDestructive
        ? AppColors.danger
        : (textColor ?? defaultColor);

    return ListTile(
      contentPadding: EdgeInsets.zero,
      leading: Icon(icon, color: resolvedColor),
      title: Text(label,
          style: TextStyle(
              color: resolvedTextColor, fontWeight: FontWeight.w600)),
      trailing: const Icon(Icons.chevron_right, size: 18),
      onTap: onTap,
    );
  }
}
